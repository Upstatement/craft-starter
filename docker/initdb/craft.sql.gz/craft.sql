-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: craft
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  KEY `assets_volumeId_keptFile_idx` (`volumeId`,`keptFile`),
  KEY `assets_filename_folderId_idx` (`filename`,`folderId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assettransformindex`
--

LOCK TABLES `assettransformindex` WRITE;
/*!40000 ALTER TABLE `assettransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `assettransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2018-12-12 22:07:59','2018-12-12 22:07:59','a9febe2a-4bb5-46e8-80c1-c2c9972671a3');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,'craft\\elements\\User',1,0,'2018-12-12 22:07:59','2018-12-12 22:07:59',NULL,'23c4dd14-2228-43c2-ba4e-7303ddaf022b');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2018-12-12 22:07:59','2018-12-12 22:07:59','d55bb1fe-5914-427e-863c-adaaaf936a75');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrydrafts`
--

DROP TABLE IF EXISTS `entrydrafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydrafts_sectionId_idx` (`sectionId`),
  KEY `entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entrydrafts_siteId_idx` (`siteId`),
  KEY `entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrydrafts`
--

LOCK TABLES `entrydrafts` WRITE;
/*!40000 ALTER TABLE `entrydrafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `entrydrafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entryversions`
--

DROP TABLE IF EXISTS `entryversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entryversions_sectionId_idx` (`sectionId`),
  KEY `entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entryversions_siteId_idx` (`siteId`),
  KEY `entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entryversions`
--

LOCK TABLES `entryversions` WRITE;
/*!40000 ALTER TABLE `entryversions` DISABLE KEYS */;
/*!40000 ALTER TABLE `entryversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_type_idx` (`type`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (12,'craft\\elements\\User','2018-12-13 19:16:10','2018-12-13 19:16:10',NULL,'1051321b-ff67-42c7-913b-07696b1e78c5');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `globalsets_handle_unq_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'3.1.14','3.1.25',0,'a:8:{s:12:\"dateModified\";i:1550870354;s:5:\"email\";a:5:{s:9:\"fromEmail\";s:26:\"$SYSTEM_EMAIL_FROM_ADDRESS\";s:8:\"fromName\";s:25:\"$SYSTEM_EMAIL_SENDER_NAME\";s:8:\"template\";N;s:17:\"transportSettings\";a:7:{s:16:\"encryptionMethod\";s:0:\"\";s:4:\"host\";s:28:\"$SYSTEM_EMAIL_SMTP_HOST_NAME\";s:8:\"password\";s:0:\"\";s:4:\"port\";s:23:\"$SYSTEM_EMAIL_SMTP_PORT\";s:7:\"timeout\";s:2:\"10\";s:17:\"useAuthentication\";s:0:\"\";s:8:\"username\";s:0:\"\";}s:13:\"transportType\";s:33:\"craft\\mail\\transportadapters\\Smtp\";}s:7:\"plugins\";a:1:{s:8:\"redactor\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"2.2.2\";}}s:10:\"siteGroups\";a:1:{s:36:\"17a658f8-aefa-400c-8d0e-898c911d1af4\";a:1:{s:4:\"name\";s:12:\"craftstarter\";}}s:5:\"sites\";a:1:{s:36:\"88bb7ef8-41f5-46d5-a33a-b5c80c65aff9\";a:8:{s:7:\"baseUrl\";s:17:\"$DEFAULT_SITE_URL\";s:6:\"handle\";s:7:\"default\";s:7:\"hasUrls\";b:1;s:8:\"language\";s:5:\"en-US\";s:4:\"name\";s:12:\"craftstarter\";s:7:\"primary\";b:1;s:9:\"siteGroup\";s:36:\"17a658f8-aefa-400c-8d0e-898c911d1af4\";s:9:\"sortOrder\";i:1;}}s:6:\"system\";a:5:{s:7:\"edition\";s:4:\"solo\";s:4:\"live\";b:1;s:4:\"name\";s:12:\"$SYSTEM_NAME\";s:13:\"schemaVersion\";s:6:\"3.1.25\";s:8:\"timeZone\";s:16:\"America/New_York\";}s:5:\"users\";a:5:{s:23:\"allowPublicRegistration\";b:0;s:12:\"defaultGroup\";N;s:12:\"photoSubpath\";s:0:\"\";s:14:\"photoVolumeUid\";N;s:24:\"requireEmailVerification\";b:1;}s:7:\"volumes\";a:1:{s:36:\"f4ac2cff-9548-4bd8-ab1d-caeaeb1d2087\";a:7:{s:6:\"handle\";s:7:\"uploads\";s:7:\"hasUrls\";b:1;s:4:\"name\";s:7:\"Uploads\";s:8:\"settings\";a:1:{s:4:\"path\";s:16:\"$ASSET_BASE_PATH\";}s:9:\"sortOrder\";i:1;s:4:\"type\";s:19:\"craft\\volumes\\Local\";s:3:\"url\";s:15:\"$ASSET_BASE_URL\";}}}','{\"dateModified\":\"@config/project.yaml\",\"email\":\"@config/project.yaml\",\"plugins\":\"@config/project.yaml\",\"siteGroups\":\"@config/project.yaml\",\"sites\":\"@config/project.yaml\",\"system\":\"@config/project.yaml\",\"users\":\"@config/project.yaml\",\"volumes\":\"@config/project.yaml\"}','ZJ8nhx9fnGDM','2018-12-12 22:07:59','2019-02-22 21:19:14','eecb9256-73d4-4579-b0b9-a6652d00292b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,NULL,'app','Install','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','b9ef3b00-6afe-4333-9a13-ba527479fb8f'),(2,NULL,'app','m150403_183908_migrations_table_changes','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a4eb2fd0-6fd8-45ca-ae4d-04c8978657c7'),(3,NULL,'app','m150403_184247_plugins_table_changes','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','1d0cde95-5690-4b6c-bce8-8765704e8a79'),(4,NULL,'app','m150403_184533_field_version','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','cb5f725a-ad68-4533-a0c0-05775612800e'),(5,NULL,'app','m150403_184729_type_columns','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','89c5fdea-c267-4713-9f1a-59c9df373e4f'),(6,NULL,'app','m150403_185142_volumes','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','62811b93-3c2e-4a32-a76b-9ba5e7d5d956'),(7,NULL,'app','m150428_231346_userpreferences','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','b70e3b7b-e4eb-4047-806d-fe6fd22a1585'),(8,NULL,'app','m150519_150900_fieldversion_conversion','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','330f1dc9-93ac-4716-8aa8-c1dd27ad4608'),(9,NULL,'app','m150617_213829_update_email_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','d13c76f6-e5cf-4ce2-9b03-2887516c96aa'),(10,NULL,'app','m150721_124739_templatecachequeries','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','b3bad587-4dc7-43f1-b4ae-465e566d437b'),(11,NULL,'app','m150724_140822_adjust_quality_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','c98e48ad-d6be-48a9-928c-4e9c61b46c87'),(12,NULL,'app','m150815_133521_last_login_attempt_ip','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','410e7647-f101-471f-be55-cd237d28e9b2'),(13,NULL,'app','m151002_095935_volume_cache_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','1a9d4061-20eb-4038-90d3-32fc6c2a0165'),(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','271ad4ee-b50c-4abc-9781-ef14f1ae1493'),(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','1092faf6-3e58-4fdb-a62e-8e3d8217e97a'),(16,NULL,'app','m151209_000000_move_logo','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','e3edd052-4720-4862-a0db-36f218ce8cdc'),(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','2f07f1f5-b3bb-4207-be95-c59f9556db81'),(18,NULL,'app','m151215_000000_rename_asset_permissions','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','8a12d888-21e2-407f-8789-e8cfcd089687'),(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','e3da2ac0-e390-4595-b29a-e386e0727260'),(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','60f3a516-026b-4d28-be78-e3bc73035518'),(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','79218719-433b-4fc4-b0e2-a229b073ae34'),(22,NULL,'app','m160727_194637_column_cleanup','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','c9aa3742-9bc4-4f11-94a3-31f78c03ddf5'),(23,NULL,'app','m160804_110002_userphotos_to_assets','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','19e35d12-87db-4c61-af37-4320ecfb4491'),(24,NULL,'app','m160807_144858_sites','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','21477d03-f579-434c-af80-1d7dba292301'),(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','dfbf5882-8bbc-4cc3-b2bd-03e5831165fe'),(26,NULL,'app','m160830_000000_asset_index_uri_increase','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','000ad6a5-5f30-4d2d-8f51-f5501cfa13dc'),(27,NULL,'app','m160912_230520_require_entry_type_id','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','9dcec022-2301-4323-a5fa-2a1aa18f6c67'),(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','87315fe3-7aa5-41c6-8dc2-d1fab149195a'),(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','bc92678d-0e84-4cec-ac4c-76fc7ceccf59'),(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','c71c2161-bac7-4673-a914-c225c6bf14dc'),(31,NULL,'app','m160925_113941_route_uri_parts','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','ea5df3d9-1149-4cc9-8247-3d1f91c1f80c'),(32,NULL,'app','m161006_205918_schemaVersion_not_null','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f96d119c-7d1d-4448-ae11-282cd0af7fde'),(33,NULL,'app','m161007_130653_update_email_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f7422716-9a4c-4103-bb59-9ef08882d156'),(34,NULL,'app','m161013_175052_newParentId','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','9d063803-3c31-4816-988e-ec0871bab67b'),(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a71f2176-ab03-4279-9b79-da1c04c5e9eb'),(36,NULL,'app','m161021_182140_rename_get_help_widget','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','206dea37-ecbe-4014-a173-702b78c0898b'),(37,NULL,'app','m161025_000000_fix_char_columns','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','814986a4-f382-48c9-9d3f-7601e3c72e50'),(38,NULL,'app','m161029_124145_email_message_languages','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','e9514e2c-65ee-4b7b-b3dc-d85c2544c41c'),(39,NULL,'app','m161108_000000_new_version_format','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','2ef77eb7-4fe5-423f-8805-8b1c7887bbbd'),(40,NULL,'app','m161109_000000_index_shuffle','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','61d36a0c-5da5-4687-8e1b-2420f4a48d3f'),(41,NULL,'app','m161122_185500_no_craft_app','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','ec6ddf0a-1088-4215-ac0f-461dd6e88fb4'),(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a6bf8a87-235b-454f-a92a-84f64974398f'),(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','9ad83747-e00e-464c-b99e-fe2e1f129ce3'),(44,NULL,'app','m170114_161144_udates_permission','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','298b7f3e-3104-4850-bbd5-536b2d5753aa'),(45,NULL,'app','m170120_000000_schema_cleanup','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','06e061ba-ab76-4f0f-9941-bef8d3e6a780'),(46,NULL,'app','m170126_000000_assets_focal_point','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','07c967ed-5aa8-4ce8-9a5c-9333e7ee3022'),(47,NULL,'app','m170206_142126_system_name','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','8a03461d-1f07-41cc-8b95-0c5f9c517228'),(48,NULL,'app','m170217_044740_category_branch_limits','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a7bd3ba5-7809-46af-88b9-366602880bc9'),(49,NULL,'app','m170217_120224_asset_indexing_columns','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','dc4f1c72-88ee-4fbb-a118-5911fe245ac6'),(50,NULL,'app','m170223_224012_plain_text_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','5778e153-3dae-404c-b02b-7a23533a944f'),(51,NULL,'app','m170227_120814_focal_point_percentage','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','5ddceae9-a8f9-4b61-8a3f-fe230acf8b96'),(52,NULL,'app','m170228_171113_system_messages','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','ab5104a7-2ad9-42ce-b97c-a83bda5e3ed5'),(53,NULL,'app','m170303_140500_asset_field_source_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','9cd429c9-b1a6-4695-bcb8-93f0ce44d73c'),(54,NULL,'app','m170306_150500_asset_temporary_uploads','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f262c9d2-a3a3-4ea8-b970-ba0f31b9e088'),(55,NULL,'app','m170414_162429_rich_text_config_setting','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','b28a9fff-e41f-49d0-a829-a324e91c50ac'),(56,NULL,'app','m170523_190652_element_field_layout_ids','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','07b5077c-68a8-4e31-8ffd-fbf44d758433'),(57,NULL,'app','m170612_000000_route_index_shuffle','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','1ffd79fe-1287-4ac7-a5c0-912c1cb6d7e6'),(58,NULL,'app','m170621_195237_format_plugin_handles','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','8fd749a2-36f4-4780-be9a-5990e6895626'),(59,NULL,'app','m170630_161028_deprecation_changes','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','43262766-d109-4914-8a2e-8d1e7f351c61'),(60,NULL,'app','m170703_181539_plugins_table_tweaks','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','29ba4952-cab3-4baf-baae-22581e3bd5ef'),(61,NULL,'app','m170704_134916_sites_tables','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','6575c7e9-db84-4ff0-86fb-5bfc2c6e6986'),(62,NULL,'app','m170706_183216_rename_sequences','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','840d3dae-8b3a-44f8-9190-9b840e0acac3'),(63,NULL,'app','m170707_094758_delete_compiled_traits','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f4a48f8b-035b-42b5-a1e4-9ad0128e74b4'),(64,NULL,'app','m170731_190138_drop_asset_packagist','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','5d7a9f12-e861-460e-baa8-807dd49481bb'),(65,NULL,'app','m170810_201318_create_queue_table','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','7c9c24f5-9805-4fa5-8f3f-bb4c2da9f119'),(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','9d8c6daf-7a71-4b42-8676-7231ac8700e6'),(67,NULL,'app','m170821_180624_deprecation_line_nullable','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','18c02910-ceb6-455c-a07d-591a6a7c8ed9'),(68,NULL,'app','m170903_192801_longblob_for_queue_jobs','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f1b3756c-5370-4357-9870-ccefa55ad2db'),(69,NULL,'app','m170914_204621_asset_cache_shuffle','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','71476b33-fccb-4a94-9041-afb1174cc0f1'),(70,NULL,'app','m171011_214115_site_groups','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','0583089c-9da2-4ab5-8103-abd183da4126'),(71,NULL,'app','m171012_151440_primary_site','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','38dc5321-54bb-4c8d-a008-c9c3c8336099'),(72,NULL,'app','m171013_142500_transform_interlace','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','473e56b7-9466-4b37-ac37-f475b7f0261d'),(73,NULL,'app','m171016_092553_drop_position_select','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','ea47e453-b639-4b92-8033-5c10b6c7ad7a'),(74,NULL,'app','m171016_221244_less_strict_translation_method','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','4c57fe94-20a9-401f-bd96-0f7649b832ae'),(75,NULL,'app','m171107_000000_assign_group_permissions','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','81281ca8-99ff-45e9-8d7e-983dc37ee257'),(76,NULL,'app','m171117_000001_templatecache_index_tune','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','3992a2d1-3f8d-4d1f-92a4-df82aff297be'),(77,NULL,'app','m171126_105927_disabled_plugins','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','262678d4-668c-4389-9d27-d2ec6ac4c83d'),(78,NULL,'app','m171130_214407_craftidtokens_table','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','ac1e9bc5-0e6d-438a-8a2c-8d527f36d21f'),(79,NULL,'app','m171202_004225_update_email_settings','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','fa89ee75-669e-496d-b8ea-d876bb74f67b'),(80,NULL,'app','m171204_000001_templatecache_index_tune_deux','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','59e64d82-f7ec-49b2-9eb1-5a8d902382ab'),(81,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','d05704f6-a3dd-4a95-aceb-b2273750b372'),(82,NULL,'app','m171218_143135_longtext_query_column','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','066da47a-34da-4126-889d-ca9ca42f78b8'),(83,NULL,'app','m171231_055546_environment_variables_to_aliases','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a567cc5e-4a73-40cc-9df0-86e5ecc6c2cc'),(84,NULL,'app','m180113_153740_drop_users_archived_column','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','a124a817-79bf-4496-81cd-3457391a323f'),(85,NULL,'app','m180122_213433_propagate_entries_setting','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','984ca9d4-a6bb-473b-8604-e37c2d5c805f'),(86,NULL,'app','m180124_230459_fix_propagate_entries_values','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','509cde7e-bc70-4f50-baf5-d845d1f4dd4d'),(87,NULL,'app','m180128_235202_set_tag_slugs','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','3af60746-22f6-4cc7-bec5-402ce1e0694f'),(88,NULL,'app','m180202_185551_fix_focal_points','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','d60c6c42-44fd-4e2d-a5d9-98b76b93b41f'),(89,NULL,'app','m180217_172123_tiny_ints','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','5695cc63-95f4-4e56-a878-43e9b2e73baf'),(90,NULL,'app','m180321_233505_small_ints','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','f617632f-0901-460d-a9a0-017dacb31247'),(91,NULL,'app','m180328_115523_new_license_key_statuses','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','4e3b6040-240f-4106-ad76-1c7d609124ed'),(92,NULL,'app','m180404_182320_edition_changes','2018-12-12 22:07:59','2018-12-12 22:07:59','2018-12-12 22:07:59','3803cae1-9c7d-4a00-9abe-06230582fb6f'),(93,NULL,'app','m180411_102218_fix_db_routes','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','c352c5ed-ddf4-4db6-940f-6d8a77bcb5d3'),(94,NULL,'app','m180416_205628_resourcepaths_table','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','04e43cbb-68b2-4e28-83c4-0c03ec19a8f4'),(95,NULL,'app','m180418_205713_widget_cleanup','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','56ca9875-daed-450d-a2dc-e403ae65ed99'),(96,NULL,'app','m180824_193422_case_sensitivity_fixes','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','85bd60e7-84de-4c38-993d-b11a35011212'),(97,NULL,'app','m180901_151639_fix_matrixcontent_tables','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','779466b9-247a-4eb1-a8d6-a73a7f6c1a6a'),(98,NULL,'app','m181112_203955_sequences_table','2018-12-12 22:08:00','2018-12-12 22:08:00','2018-12-12 22:08:00','27ffdce4-8cb3-4930-943d-1f0b748741ac'),(99,NULL,'app','m170630_161027_deprecation_line_nullable','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','c414ddd7-3092-47a4-ba06-e7292c0077d7'),(100,NULL,'app','m180425_203349_searchable_fields','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','05bde190-d83f-448d-9679-e336b53f4e45'),(101,NULL,'app','m180516_153000_uids_in_field_settings','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','e7cc7d07-0913-49d3-ac34-9a27235319a5'),(102,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','61441f9c-efd0-457c-85c6-d739015f2d93'),(103,NULL,'app','m180518_173000_permissions_to_uid','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','71099c7d-1a5c-4040-a221-ecff5631ee3d'),(104,NULL,'app','m180520_173000_matrix_context_to_uids','2019-02-22 21:04:04','2019-02-22 21:04:04','2019-02-22 21:04:04','c4e322c1-d606-48c5-a44e-c2ee215f6df6'),(105,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','dff135f3-858e-441f-85e2-44453fa16eb7'),(106,NULL,'app','m180731_162030_soft_delete_sites','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','4328571a-1f9b-489c-b068-da88d6f77af3'),(107,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','92341a85-e6cb-43ee-9dbf-51f199f4e3d3'),(108,NULL,'app','m180810_214439_soft_delete_elements','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','40f94780-0d8f-445e-9225-5522647a7495'),(109,NULL,'app','m180904_112109_permission_changes','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','d4a1ea37-54dd-41ad-9374-61c767a9f5be'),(110,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','9f73043e-d872-4d3e-a3e2-b527a635c3d8'),(111,NULL,'app','m181011_160000_soft_delete_asset_support','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','a918df5b-1ad1-4bd1-a2fd-de7a7dd098f1'),(112,NULL,'app','m181016_183648_set_default_user_settings','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','17834eff-ab92-492d-89ed-72eb4978e923'),(113,NULL,'app','m181017_225222_system_config_settings','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','8a6814f3-2636-4f7a-a564-96c82ef28d35'),(114,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','23e8c7cb-26aa-42c3-b8c2-826db56912df'),(115,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','4341f501-7e50-4aad-bbc7-769cef530dc9'),(116,NULL,'app','m181121_001712_cleanup_field_configs','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','0f463187-4211-4bbb-90f9-c5b2e65e83c9'),(117,NULL,'app','m181128_193942_fix_project_config','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','bc8d5a82-ccc4-46de-907e-19d1a049d399'),(118,NULL,'app','m181130_143040_fix_schema_version','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','eb218e00-e225-4ce5-83b8-b8531fe2d5b1'),(119,NULL,'app','m181211_143040_fix_entry_type_uids','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','7e269e27-3d20-4f83-b6ea-59ff69fb7bbb'),(120,NULL,'app','m181213_102500_config_map_aliases','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','e3dfcf31-067c-4192-b37d-57d9a2389100'),(121,NULL,'app','m181217_153000_fix_structure_uids','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','ea899c45-9e9a-4220-9f35-2045fac6cbb5'),(122,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','dd6c916b-361c-4267-a13d-d8c183705fed'),(123,NULL,'app','m190108_110000_cleanup_project_config','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','0107f9b1-086a-4102-b5be-e3cff9ae091e'),(124,NULL,'app','m190108_113000_asset_field_setting_change','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','a5a61316-835b-4b99-9632-c46ca014a783'),(125,NULL,'app','m190109_172845_fix_colspan','2019-02-22 21:04:05','2019-02-22 21:04:05','2019-02-22 21:04:05','1d36e9ac-2fff-432e-94f9-9809e987d8ff'),(126,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','90e6b662-8ff5-4746-b316-0948dcbf597a'),(127,NULL,'app','m190110_214819_soft_delete_volumes','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','e4b35224-14c8-4e98-b5b4-0fef9a8fe163'),(128,NULL,'app','m190112_124737_fix_user_settings','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','7babe9b8-a931-4cf6-a3b4-a4fafa79c077'),(129,NULL,'app','m190112_131225_fix_field_layouts','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','525b4ca8-bae6-44e1-b29a-ff4691ebb3cf'),(130,NULL,'app','m190112_201010_more_soft_deletes','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','703e6deb-28aa-45de-b43c-5ffe674b411b'),(131,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','e86352d0-72c7-408f-a929-69fc39826789'),(132,NULL,'app','m190121_120000_rich_text_config_setting','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','b12e8562-caff-4e05-8dee-b534440184fa'),(133,NULL,'app','m190125_191628_fix_email_transport_password','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','9fb007ce-c61c-4826-ab4e-18d0b43dc7fc'),(134,NULL,'app','m190128_181422_cleanup_volume_folders','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','907a5e7a-0b33-471c-8c00-209349460488'),(135,NULL,'app','m190205_140000_fix_asset_soft_delete_index','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','023a1555-107d-4275-b026-d3d779d415dd'),(136,NULL,'app','m190208_140000_reset_project_config_mapping','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','7f0a25e3-336b-49ce-9c41-9b7792fbcc3a'),(137,NULL,'app','m190218_143000_element_index_settings_uid','2019-02-22 21:04:06','2019-02-22 21:04:06','2019-02-22 21:04:06','4da83b4a-009d-49c5-b77a-643696c4b88d'),(138,2,'plugin','m180430_204710_remove_old_plugins','2019-02-22 21:06:26','2019-02-22 21:06:26','2019-02-22 21:06:26','2fc12152-6d05-4bfd-81b2-0db91b141cb6'),(139,2,'plugin','Install','2019-02-22 21:06:26','2019-02-22 21:06:26','2019-02-22 21:06:26','b7242b1d-d615-4ae0-8d6a-18ac1604d178'),(140,2,'plugin','m181101_110000_ids_in_settings_to_uids','2019-02-22 21:06:26','2019-02-22 21:06:26','2019-02-22 21:06:26','aa3ed5db-da36-44b4-b65f-45816317389e');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (2,'redactor','2.3.2','2.2.2','unknown',NULL,'2019-02-22 21:06:26','2019-02-22 21:06:26','2019-02-22 21:19:26','da2ca652-b228-40e0-97ca-3893beb5c442');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('10b03506','@lib/jquery.payment'),('15a3862e','@craft/web/assets/recententries/dist'),('1b63298','@craft/web/assets/updates/dist'),('1c60c071','@craft/web/assets/updater/dist'),('1d186d93','@bower/jquery/dist'),('1fde4875','@app/web/assets/plugins/dist'),('2236901b','@craft/web/assets/generalsettings/dist'),('224790ce','@lib/selectize'),('2468b587','@craft/web/assets/cp/dist'),('282bd444','@lib/xregexp'),('31671dd1','@craft/web/assets/cp/dist'),('3288c666','@lib/element-resize-detector'),('359bb5b5','@app/web/assets/edituser/dist'),('37483898','@lib/selectize'),('381c2dac','@craft/web/assets/pluginstore/dist'),('38676dce','@craft/web/assets/dashboard/dist'),('3d247c12','@lib/xregexp'),('3e166c16','@craft/web/assets/updateswidget/dist'),('41244b05','@craft/web/assets/feed/dist'),('423e014b','@lib/jquery-ui'),('481aad30','@app/web/assets/dashboard/dist'),('4b218a9d','@lib/garnishjs'),('4b68f6f5','@lib/fabric'),('4bad3f18','@craft/web/assets/fields/dist'),('4f7d837e','@app/web/assets/fields/dist'),('57e76241','@app/web/assets/updates/dist'),('5d150566','@app/web/assets/dashboard/dist'),('5e2e22cb','@lib/garnishjs'),('5e675ea3','@lib/fabric'),('6336151c','@lib/picturefill'),('649229de','@lib/jquery-touch-events'),('66142357','@lib/prismjs'),('6b95251b','@craft/web/assets/utilities/dist'),('6bd86ce8','@app/web/assets/sites/dist'),('6d93354d','@lib/d3'),('6ed1bcb4','@lib/fileupload'),('719d8188','@lib/jquery-touch-events'),('754db738','@craft/web/assets/sites/dist'),('7639bd4a','@lib/picturefill'),('789c9d1b','@lib/d3'),('7bde14e2','@lib/fileupload'),('7e317641','@craft/web/assets/craftsupport/dist'),('7ed7c4be','@app/web/assets/sites/dist'),('83556ca7','@app/web/assets/recententries/dist'),('895a50ea','@lib/fileupload'),('8b17e37c','@app/web/assets/cp/dist'),('8cb53249','@craft/web/assets/craftsupport/dist'),('8f29f602','@app/web/assets/login/dist'),('902fae57','@app/web/assets/pluginstore/dist'),('91b25114','@lib/picturefill'),('91bc2dd2','@craft/web/assets/login/dist'),('9490675f','@lib/prismjs'),('96166dd6','@lib/jquery-touch-events'),('965ac4f1','@app/web/assets/recententries/dist'),('99116113','@craft/web/assets/utilities/dist'),('99ba9a1f','@craft/web/assets/craftsupport/dist'),('9a265e54','@app/web/assets/login/dist'),('9e184b2a','@app/web/assets/cp/dist'),('9f177145','@lib/d3'),('a5b5ed15','@lib/jquery-ui'),('a6722a5e','@app/web/assets/craftsupport/dist'),('a6afa75b','@craft/web/assets/feed/dist'),('a8e0869f','@app/web/assets/updateswidget/dist'),('a94b42d8','@app/web/assets/generalsettings/dist'),('ac2e78','@craft/web/assets/recententries/dist'),('acaa66c3','@lib/garnishjs'),('ad1e023','@app/web/assets/plugins/dist'),('ae04f4f2','@craft/web/assets/plugins/dist'),('b0ba4543','@lib/jquery-ui'),('b37d8208','@app/web/assets/craftsupport/dist'),('b3a00f0d','@craft/web/assets/feed/dist'),('b9ecb2fd','@lib/fabric'),('bb0b5ca4','@craft/web/assets/plugins/dist'),('bc44ea8e','@app/web/assets/generalsettings/dist'),('bdef2ec9','@app/web/assets/updateswidget/dist'),('c00c826e','@lib/element-resize-detector'),('c3e359d9','@craft/web/assets/cp/dist'),('c5cc7c90','@lib/selectize'),('c979aee','@lib/velocity'),('cae329c6','@craft/web/assets/dashboard/dist'),('cfa0381a','@lib/xregexp'),('d5032a38','@lib/element-resize-detector'),('d7b6e863','@lib'),('dfec8190','@craft/web/assets/dashboard/dist'),('e234710e','@lib/jquery.payment'),('e7030094','@app/web/assets/feed/dist'),('e727c226','@craft/web/assets/recententries/dist'),('e96ca1ed','@app/web/assets/utilities/dist'),('eb1c76b0','@lib/velocity'),('eee48479','@craft/web/assets/updater/dist'),('ef9c299b','@bower/jquery/dist'),('f20ca8c2','@app/web/assets/feed/dist'),('f3327690','@craft/web/assets/updates/dist'),('f73bd958','@lib/jquery.payment'),('fa9381cd','@bower/jquery/dist'),('fe13dee6','@lib/velocity');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' admin '),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'fullname',0,1,''),(1,'email',0,1,' tech upstatement com '),(1,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagateEntries` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_handle_idx` (`handle`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'Lq70X-hBACyRLZpXbRmwOIoSPeCAXuh9lWT_k7r7E4pANWxVkj47iCmGix8No_19Tm5WMyDd5EUNgevixhtTag0d2_18b_pu-5Nt','2018-12-12 22:10:11','2018-12-12 23:09:56','691d4c92-d835-4098-9e95-e8c13bef4054'),(2,1,'vwhCvDxRzDpxDnadBsq7V-Nee3i0_KSVtDJc3dTI1wdc8w5SfTefwIUwZ6_NM5niwQdKIY3rRrnL4-WJaQGN_PWhcfJ7NG2yrlt1','2018-12-13 15:20:28','2018-12-13 15:23:34','67b75270-b4f6-413e-8b40-267a8d06c50f'),(3,1,'897u55DiZQwwFkPf3dyMbNkSadNYrmPtAJtw0ybZsdzMWS-LjfysrOpJeOoAsDkKKMzvBB6ZSc7tef-JPjw2IwDFW3WdYiOGxma-','2018-12-13 18:57:32','2018-12-13 19:01:21','6b15689a-b579-4f85-b229-da92ae43d58b'),(4,1,'6PK0CJ9U49P_CZpjkhCnV_RLORbhvMRC3mfNGo-7rg4E8W3XxhNnSjRuNTFqTMinbJynej-pI5-U_7PsMBGCeF9NHLb4Dq1mH0ZG','2019-02-22 21:04:27','2019-02-22 21:19:28','8542db09-4f8e-4c62-846e-48408da5aa6b');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_dateDeleted_idx` (`dateDeleted`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'craftstarter','2018-12-12 22:07:59','2018-12-12 22:07:59',NULL,'17a658f8-aefa-400c-8d0e-898c911d1af4');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'craftstarter','default','en-US',1,'$DEFAULT_SITE_URL',1,'2018-12-12 22:07:59','2019-02-22 21:09:48',NULL,'88bb7ef8-41f5-46d5-a33a-b5c80c65aff9');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecacheelements`
--

LOCK TABLES `templatecacheelements` WRITE;
/*!40000 ALTER TABLE `templatecacheelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecacheelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecachequeries`
--

LOCK TABLES `templatecachequeries` WRITE;
/*!40000 ALTER TABLE `templatecachequeries` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecachequeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecaches`
--

LOCK TABLES `templatecaches` WRITE;
/*!40000 ALTER TABLE `templatecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,NULL,'tech@upstatement.com','$2y$13$qom1nDwajURp8ewMCpM82OWrLd2uyxt68gV6n6lnwwjkEtWcAdef.',1,0,0,0,'2019-02-22 21:04:27','172.18.0.1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2018-12-12 22:07:59','2018-12-12 22:07:59','2019-02-22 21:04:27','b41048a7-1e57-4fdd-b940-d08f4015ad92');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Uploads','','2019-02-22 21:16:01','2019-02-22 21:16:01','6f6ef6d6-4fc9-402e-bb91-06e6b8fc29a5'),(2,NULL,NULL,'Temporary source',NULL,'2019-02-22 21:18:03','2019-02-22 21:18:03','d544b828-cb3f-477f-8a0b-87617757299f'),(3,2,NULL,'user_1','user_1/','2019-02-22 21:18:03','2019-02-22 21:18:03','d0efaf30-9328-437e-b581-e5fa7a513189');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,NULL,'Uploads','uploads','craft\\volumes\\Local',1,'$ASSET_BASE_URL','{\"path\":\"$ASSET_BASE_PATH\"}',NULL,'2019-02-22 21:16:00','2019-02-22 21:16:00',NULL,'f4ac2cff-9548-4bd8-ab1d-caeaeb1d2087');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,0,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2018-12-12 22:10:12','2018-12-12 22:10:12','dd86e990-51af-4167-a6e2-142208419b3f'),(2,1,'craft\\widgets\\CraftSupport',2,0,'[]',1,'2018-12-12 22:10:12','2018-12-12 22:10:12','6bf1a1fe-1aa0-4024-b03b-4781e85a819c'),(3,1,'craft\\widgets\\Updates',3,0,'[]',1,'2018-12-12 22:10:12','2018-12-12 22:10:12','4218ac2a-9c35-42aa-aab6-508e6eacf1a8'),(4,1,'craft\\widgets\\Feed',4,0,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2018-12-12 22:10:12','2018-12-12 22:10:12','e07be5f9-b76f-46ff-8f43-9577daba4d74');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-22 16:19:45
